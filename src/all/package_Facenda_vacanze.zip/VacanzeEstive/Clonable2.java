package all.VacanzeEstive;

public interface Clonable2<T> {
    public T clone2() throws CloneNotSupportedException;
}
